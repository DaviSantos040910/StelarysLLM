# studio/schemas.py

from google.genai import types

# Esquema para Quiz
# {"type": "array", "items": {...}}
QUIZ_SCHEMA = types.Schema(
    type=types.Type.OBJECT,
    properties={
        "title": types.Schema(type=types.Type.STRING),
        "questions": types.Schema(
            type=types.Type.ARRAY,
            items=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "question": types.Schema(type=types.Type.STRING),
                    "options": types.Schema(
                        type=types.Type.ARRAY,
                        items=types.Schema(type=types.Type.STRING)
                    ),
                    "correctAnswerIndex": types.Schema(type=types.Type.INTEGER),
                    "explanation": types.Schema(type=types.Type.STRING),
                    "hint": types.Schema(type=types.Type.STRING)
                },
                required=["question", "options", "correctAnswerIndex", "explanation", "hint"]
            )
        )
    },
    required=["title", "questions"]
)

# Esquema para Flashcards
FLASHCARD_SCHEMA = types.Schema(
    type=types.Type.OBJECT,
    properties={
        "title": types.Schema(type=types.Type.STRING),
        "cards": types.Schema(
            type=types.Type.ARRAY,
            items=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "front": types.Schema(type=types.Type.STRING),
                    "back": types.Schema(type=types.Type.STRING)
                },
                required=["front", "back"]
            )
        )
    },
    required=["title", "cards"]
)

# Esquema para Resumo
SUMMARY_SCHEMA = types.Schema(
    type=types.Type.OBJECT,
    properties={
        "title": types.Schema(type=types.Type.STRING),
        "summary": types.Schema(type=types.Type.STRING),
        "key_points": types.Schema(
            type=types.Type.ARRAY,
            items=types.Schema(type=types.Type.STRING)
        )
    },
    required=["title", "summary", "key_points"]
)

# Esquema para Slides
SLIDE_SCHEMA = types.Schema(
    type=types.Type.OBJECT,
    properties={
        "title": types.Schema(type=types.Type.STRING),
        "slides": types.Schema(
            type=types.Type.ARRAY,
            items=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "title": types.Schema(type=types.Type.STRING),
                    "bullets": types.Schema(
                        type=types.Type.ARRAY,
                        items=types.Schema(type=types.Type.STRING)
                    )
                },
                required=["title", "bullets"]
            )
        )
    },
    required=["title", "slides"]
)
