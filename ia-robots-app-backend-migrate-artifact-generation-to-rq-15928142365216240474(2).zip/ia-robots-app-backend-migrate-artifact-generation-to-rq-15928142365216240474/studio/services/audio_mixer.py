import os
import logging
import uuid
import tempfile
import concurrent.futures
from django.conf import settings
from pydub import AudioSegment
from chat.services.tts_service import generate_tts_audio
from chat.services.voice_mapping import get_gemini_voice

logger = logging.getLogger(__name__)

class AudioMixerService:
    @staticmethod
    def mix_podcast(script, bot_voice_enum: str = None) -> tuple[str, list, int]:
        """
        Mixes a podcast script into a single audio file using parallel TTS generation.
        script: List of dicts (Legacy) OR Dict with 'dialogue' key (New).
        bot_voice_enum: The Bot.voice value to map to a real Gemini voice for the Host.
        Returns: (Relative path to the generated audio file in MEDIA_ROOT, transcript list, total_duration_ms)
        """
        if not script:
            raise ValueError("Script is empty.")

        # Normalize Script: Handle Legacy List vs New Dict
        dialogue = script
        if isinstance(script, dict):
            dialogue = script.get('dialogue', [])

        if not dialogue:
             raise ValueError("Dialogue is empty.")

        # Resolve Host Voice
        host_voice = get_gemini_voice(bot_voice_enum)
        cohost_voice = "Fenrir" # Fixed generic co-host

        def get_voice_for_speaker(speaker_val):
            # Maps from schema ENUM or legacy display name
            if speaker_val == "HOST" or (isinstance(speaker_val, str) and speaker_val.upper().startswith("HOST")):
                return host_voice
            elif speaker_val == "COHOST" or speaker_val == "Co-host":
                return cohost_voice
            return host_voice # Fallback

        temp_files = []
        # Store segments in order: {index: AudioSegment}
        segments_map = {}

        def process_turn(index, turn):
            speaker = turn.get("speaker", "Host")
            text = turn.get("text", "")
            if not text:
                return None

            voice = get_voice_for_speaker(speaker)

            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf:
                temp_path = tf.name

            # This is thread-safe as temp_path is unique per call
            result = generate_tts_audio(text, temp_path, voice_name=voice)

            if result.get('success'):
                return (index, temp_path)
            else:
                logger.warning(f"Failed to generate audio for turn {index}: {result.get('error')}")
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                return None

        try:
            # Parallel Execution
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                futures = []
                for i, turn in enumerate(dialogue):
                    futures.append(executor.submit(process_turn, i, turn))

                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result:
                        idx, path = result
                        temp_files.append(path)
                        try:
                            seg = AudioSegment.from_wav(path)
                            segments_map[idx] = seg
                        except Exception as e:
                            logger.error(f"Error reading WAV {path}: {e}")

            # Mix in Order & Build Transcript
            full_audio = AudioSegment.empty()
            silence = AudioSegment.silent(duration=300)
            transcript = []
            current_ms = 0

            # Iterate by original index to preserve order
            for i in range(len(dialogue)):
                if i in segments_map:
                    segment = segments_map[i]
                    turn = dialogue[i]

                    start_ms = current_ms
                    duration_ms = len(segment)
                    end_ms = start_ms + duration_ms

                    # Append to transcript
                    transcript.append({
                        "turn_index": turn.get("turn_index", i),
                        "speaker": turn.get("speaker", "Unknown"),
                        "display_name": turn.get("display_name", turn.get("speaker", "Unknown")),
                        "text": turn.get("text", ""),
                        "start_ms": start_ms,
                        "end_ms": end_ms
                    })

                    full_audio += segment
                    current_ms += duration_ms

                    # Add silence between turns
                    full_audio += silence
                    current_ms += len(silence)

            # Export Final Mix
            filename = f"podcast_mix_{uuid.uuid4().hex[:10]}.mp3"

            # Use Tempfile for robustness on Cloud Run (avoid MEDIA_ROOT read-only issues)
            # The artifact runner handles uploading this file to storage.
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tf:
                output_path = tf.name

            full_audio.export(output_path, format="mp3", bitrate="128k")

            # Return absolute path, runner handles relative path for URL
            return output_path, transcript, len(full_audio)

        except Exception as e:
            logger.error(f"Error mixing podcast: {e}")
            raise e
        finally:
            # Cleanup temp files
            for f in temp_files:
                if os.path.exists(f):
                    try:
                        os.remove(f)
                    except: pass
