# accounts/serializers.py
from django.contrib.auth import get_user_model, authenticate
from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    class Meta:
        model = User
        fields = ("username", "email", "password")

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("Email already registered.")
        return value

    def validate_username(self, value):
        if User.objects.filter(username__iexact=value).exists():
            raise serializers.ValidationError("Username taken.")
        return value

    def validate_password(self, value):
        # Use Django's password validation
        validate_password(value)
        return value

    def create(self, validated_data):
        # create user but do not mark email verified yet
        user = User.objects.create_user(
            username=validated_data["username"],
            email=validated_data["email"],
            password=validated_data["password"],
        )
        user.is_active = True  # allow login only after verification? You can toggle.
        user.save()
        return user

class LoginSerializer(serializers.Serializer):
    identifier = serializers.CharField()
    password = serializers.CharField()

class UserSerializer(serializers.ModelSerializer):
    # Ensure all updateable fields are included
    class Meta:
        model = User
        fields = ("id", "username", "email", "first_name", "last_name", "avatar", "is_email_verified", "is_premium")
        read_only_fields = ("email", "is_email_verified", "is_premium")

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_new_password(self, value):
        validate_password(value)
        return value
