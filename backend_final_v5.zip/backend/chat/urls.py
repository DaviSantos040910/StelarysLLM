# chat/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ActiveChatListView, # Renamed from ChatListCreateView
    ChatMessageListView, 
    AudioTranscriptionView,
    ChatBootstrapView,
    ArchiveChatView,      # New import
    ArchivedChatListView, # New import
    SetActiveChatView,
    ChatMessageAttachmentView,
    MessageTTSView,
    MessageLikeToggleView,
    VoiceInteractionView,
    VoiceMessageView,
    StreamChatMessageView,
    ContextSourcesView,
    ChatSourceViewSet

)

# Router for ViewSets
router = DefaultRouter()
# Note: We need a custom router or nested router for chats/<pk>/sources, 
# but for simplicity we can just map it manually or use a flattened path if acceptable.
# Let's use manual path mapping to keep consistency with existing generic views
# or registers a simple router if we weren't nesting deeply.
# Since DRF routers are for /resource/, nesting usually requires drf-nested-routers package or manual lookup.
# We'll use manual lookup in ViewSet via self.kwargs['chat_pk']

chat_sources_list = ChatSourceViewSet.as_view({
    'get': 'list',
    'post': 'create'
})
chat_sources_detail = ChatSourceViewSet.as_view({
    'get': 'retrieve',
    'delete': 'remove' # Custom action or standard destroy? ViewSet uses destroy.
    # Our view has `remove` action mapped to delete method on detail?
    # Let's check ViewSet implementation above. 
    # I defined `remove` as @action(methods=['delete']). 
    # Standard `destroy` deletes the object. `remove` unlinks. 
    # Let's map DELETE to `remove`.
})

urlpatterns = [
    # GET /api/v1/chats/ -> Lists active chats for the main screen
    path('', ActiveChatListView.as_view(), name='active-chat-list'),
    
    # GET /api/v1/chats/archived/bot/<bot_id>/ -> Lists archived chats for a bot
    path('archived/bot/<int:bot_id>/', ArchivedChatListView.as_view(), name='archived-chat-list'),
    
    # POST /api/v1/chats/<chat_id>/archive/ -> Archives a chat and creates a new one
    path('<int:chat_id>/archive/', ArchiveChatView.as_view(), name='archive-chat'),
    
    path('<int:chat_id>/set-active/', SetActiveChatView.as_view(), name='set-active-chat'),

    path('bootstrap/bot/<int:bot_id>/', ChatBootstrapView.as_view(), name='chat-bootstrap'),
    path('<int:chat_pk>/messages/', ChatMessageListView.as_view(), name='chat-message-list-create'),
    path('<int:chat_pk>/messages/attach/', ChatMessageAttachmentView.as_view(), name='chat-message-attach'),
    path('<int:chat_pk>/messages/<str:message_id>/tts/', MessageTTSView.as_view(), name='message-tts'),
    path('<int:chat_pk>/messages/<str:message_id>/like/', MessageLikeToggleView.as_view(), name='message-like'),
    path('<int:chat_pk>/transcribe/', AudioTranscriptionView.as_view(), name='audio-transcription'),
    path('<int:chat_pk>/voice/', VoiceInteractionView.as_view(), name='chat-voice'),
    path('<int:chat_pk>/voice-message/', VoiceMessageView.as_view(), name='chat-voice-message'),
    path('<int:pk>/stream/', StreamChatMessageView.as_view(), name='chat-message-stream'),

    # Context Sources - Nested under chat ID
    path('<int:chat_id>/context-sources/', ContextSourcesView.as_view(), name='context-sources'),

    # Chat Source Management (New)
    path('<int:chat_pk>/sources/', chat_sources_list, name='chat-sources-list'),
    path('<int:chat_pk>/sources/<int:pk>/', chat_sources_detail, name='chat-sources-detail'),
]
