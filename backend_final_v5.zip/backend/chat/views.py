# chat/views.py
"""
Views para o módulo de chat.
Inclui endpoints REST padrão e SSE para streaming.
"""

import os
import re
import json
import uuid
import mimetypes
import logging
from pathlib import Path

from django.conf import settings
from django.db import transaction
from django.http import FileResponse, StreamingHttpResponse, JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.core.files import File

from rest_framework import generics, permissions, status, parsers, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import action
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError

from .models import Chat, ChatMessage
from .serializers import (
    ChatListSerializer,
    ChatMessageSerializer,
    ChatMessageAttachmentSerializer
)
from bots.models import Bot
from studio.models import KnowledgeSource
from studio.serializers import KnowledgeSourceSerializer
from .services import (
    get_ai_response,
    transcribe_audio_gemini,
    generate_tts_audio,
    handle_voice_interaction,
    handle_voice_message,
    process_message_stream,
    content_extractor
)
from myproject.pagination import StandardMessagePagination
from .vector_service import vector_service
from .file_processor import FileProcessor

logger = logging.getLogger(__name__)


# =============================================================================
# VIEWS DE LISTAGEM DE CHATS
# =============================================================================

class ActiveChatListView(generics.ListAPIView):
    """Lista todos os chats ativos do usuário."""
    serializer_class = ChatListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Chat.objects.filter(
            user=self.request.user,
            status=Chat.ChatStatus.ACTIVE
        ).order_by('-last_message_at')


class ArchivedChatListView(generics.ListAPIView):
    """Lista chats arquivados de um bot específico."""
    serializer_class = ChatListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        bot_id = self.kwargs['bot_id']
        return Chat.objects.filter(
            user=self.request.user,
            bot_id=bot_id,
            status=Chat.ChatStatus.ARCHIVED
        ).order_by('-last_message_at')


# =============================================================================
# VIEWS DE BOOTSTRAP E MENSAGENS
# =============================================================================

class ChatBootstrapView(APIView):
    """Inicializa ou retorna o chat ativo para um bot."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, bot_id):
        bot = get_object_or_404(Bot, id=bot_id)
        active_chat = Chat.objects.filter(
            user=request.user,
            bot=bot,
            status=Chat.ChatStatus.ACTIVE
        ).first()

        if not active_chat:
            active_chat = Chat.objects.create(
                user=request.user,
                bot=bot,
                status=Chat.ChatStatus.ACTIVE
            )

        # Construir URL do avatar
        avatar_url_path = None
        if bot.avatar_url and hasattr(bot.avatar_url, 'url'):
            try:
                avatar_url_path = request.build_absolute_uri(bot.avatar_url.url)
            except Exception:
                avatar_url_path = bot.avatar_url.url

        return Response({
            "conversationId": str(active_chat.id),
            "bot": {
                "name": bot.name,
                "handle": f"@{bot.owner.username}",
                "avatarUrl": avatar_url_path
            },
            "welcome": bot.description or "Hello! How can I help you today?",
            "suggestions": [s for s in [bot.suggestion1, bot.suggestion2, bot.suggestion3] if s]
        }, status=status.HTTP_200_OK)


class ChatMessageListView(generics.ListCreateAPIView):
    """Lista e cria mensagens em um chat (modo não-streaming)."""
    serializer_class = ChatMessageSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardMessagePagination

    def get_queryset(self):
        chat_id = self.kwargs['chat_pk']
        get_object_or_404(Chat, id=chat_id, user=self.request.user)
        return ChatMessage.objects.filter(chat_id=chat_id).order_by('-created_at')

    def create(self, request, *args, **kwargs):
        # Validar Content-Type
        if not request.content_type or 'application/json' not in request.content_type.lower():
            return Response(
                {"detail": "Content-Type must be application/json for text messages."},
                status=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE
            )

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        chat_id = self.kwargs['chat_pk']
        chat = get_object_or_404(Chat, id=chat_id, user=self.request.user)

        if chat.status != Chat.ChatStatus.ACTIVE:
            return Response(
                {"detail": "This chat is archived and read-only."},
                status=status.HTTP_403_FORBIDDEN
            )

        reply_with_audio = request.data.get('reply_with_audio', False)

        # Salvar mensagem do usuário
        user_message = serializer.save(chat=chat, role=ChatMessage.Role.USER)
        chat.last_message_at = timezone.now()
        chat.save()

        # Obter resposta da IA
        ai_response_data = get_ai_response(
            chat_id,
            user_message.content,
            user_message_obj=user_message,
            reply_with_audio=reply_with_audio
        )

        ai_content = ai_response_data.get('content')
        ai_suggestions = ai_response_data.get('suggestions', [])
        audio_path = ai_response_data.get('audio_path')
        duration_ms = ai_response_data.get('duration_ms', 0)
        generated_image_path = ai_response_data.get('generated_image_path')

        ai_messages = []

        # Fluxo de imagem gerada
        if generated_image_path:
            ai_message = ChatMessage(
                chat=chat,
                role=ChatMessage.Role.ASSISTANT,
                content=ai_content,
                suggestion1=ai_suggestions[0] if len(ai_suggestions) > 0 else None,
                suggestion2=ai_suggestions[1] if len(ai_suggestions) > 1 else None,
            )
            ai_message.attachment.name = generated_image_path
            ai_message.attachment_type = 'image'
            ai_message.original_filename = "generated_image.png"
            ai_message.save()
            ai_messages.append(ai_message)
            chat.last_message_at = timezone.now()
            chat.save()

        # Fluxo de áudio TTS
        elif audio_path and os.path.exists(audio_path):
            ai_message = ChatMessage(
                chat=chat,
                role=ChatMessage.Role.ASSISTANT,
                content=ai_content,
                suggestion1=ai_suggestions[0] if len(ai_suggestions) > 0 else None,
                suggestion2=ai_suggestions[1] if len(ai_suggestions) > 1 else None,
                duration=duration_ms
            )
            try:
                with open(audio_path, 'rb') as f:
                    filename = f"reply_tts_{uuid.uuid4().hex[:10]}.wav"
                    ai_message.attachment.save(filename, File(f), save=False)
                ai_message.attachment_type = 'audio'
                ai_message.original_filename = "voice_reply.wav"
                os.remove(audio_path)
            except Exception as e:
                logger.error(f"Erro ao anexar áudio TTS: {e}")
            ai_message.save()
            ai_messages.append(ai_message)

        # Fluxo de texto padrão
        else:
            paragraphs = re.split(r'\n{2,}', ai_content.strip()) if ai_content else []
            if not paragraphs:
                paragraphs = ["..."]

            total_paragraphs = len(paragraphs)
            for i, paragraph_content in enumerate(paragraphs):
                is_last_paragraph = i == (total_paragraphs - 1)
                suggestions = ai_suggestions if is_last_paragraph else []
                ai_message = ChatMessage(
                    chat=chat,
                    role=ChatMessage.Role.ASSISTANT,
                    content=paragraph_content,
                    suggestion1=suggestions[0] if len(suggestions) > 0 else None,
                    suggestion2=suggestions[1] if len(suggestions) > 1 else None,
                )
                ai_message.save()
                ai_messages.append(ai_message)

        if ai_messages:
            chat.last_message_at = ai_messages[-1].created_at
            chat.save()

        all_new_messages = [user_message] + ai_messages
        response_serializer = self.get_serializer(
            all_new_messages,
            many=True,
            context={'request': request}
        )
        return Response(response_serializer.data, status=status.HTTP_201_CREATED)


# =============================================================================
# VIEW DE STREAMING SSE (Usando Django View básico)
# =============================================================================

@method_decorator(csrf_exempt, name='dispatch')
class StreamChatMessageView(View):
    """
    Endpoint SSE para chat com streaming de texto.
    
    Usa Django View básico (não DRF) para evitar problemas de 
    content negotiation com Server-Sent Events.
    
    URL: POST /api/v1/chats/<pk>/stream/
    """

    def _authenticate(self, request):
        """
        Autentica o usuário via JWT Bearer token.
        Retorna o usuário ou None se falhar.
        """
        auth_header = request.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            return None

        token = auth_header.split(' ', 1)[1]
        jwt_auth = JWTAuthentication()

        try:
            validated_token = jwt_auth.get_validated_token(token)
            user = jwt_auth.get_user(validated_token)
            return user
        except (InvalidToken, TokenError) as e:
            logger.warning(f"[Stream] JWT auth failed: {e}")
            return None

    def post(self, request, pk):
        """Processa POST request e retorna SSE stream."""
        # 1. Autenticação manual
        user = self._authenticate(request)
        if not user:
            return JsonResponse(
                {"detail": "Authentication credentials were not provided."},
                status=401
            )

        # 2. Verificar se o chat pertence ao usuário
        try:
            chat = Chat.objects.get(id=pk, user=user)
        except Chat.DoesNotExist:
            return JsonResponse({"detail": "Chat not found."}, status=404)

        if chat.status != Chat.ChatStatus.ACTIVE:
            return JsonResponse(
                {"detail": "This chat is archived."},
                status=403
            )

        # 3. Parsear body JSON
        try:
            body = json.loads(request.body.decode('utf-8'))
            content = body.get('content', '').strip()
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JsonResponse({"detail": "Invalid JSON body."}, status=400)

        if not content:
            return JsonResponse({"detail": "Content is required."}, status=400)

        # 4. Salvar mensagem do usuário
        ChatMessage.objects.create(
            chat=chat,
            role=ChatMessage.Role.USER,
            content=content
        )
        chat.last_message_at = timezone.now()
        chat.save()

        # 5. Criar e retornar StreamingHttpResponse
        response = StreamingHttpResponse(
            process_message_stream(user.id, chat.id, content),
            content_type='text/event-stream'
        )
        
        # Headers essenciais para SSE
        response['Cache-Control'] = 'no-cache'
        response['X-Accel-Buffering'] = 'no'
        
        return response


# =============================================================================
# VIEWS DE ANEXOS E UPLOAD
# =============================================================================

class ChatMessageAttachmentView(generics.CreateAPIView):
    """
    Upload de anexos com processamento RAG síncrono.
    Suporta PDFs, DOCX e TXT para indexação vetorial.
    """
    serializer_class = ChatMessageAttachmentSerializer
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def create(self, request, *args, **kwargs):
        chat_id = self.kwargs['chat_pk']
        chat = get_object_or_404(Chat, id=chat_id, user=self.request.user)

        if chat.status != Chat.ChatStatus.ACTIVE:
            return Response({"detail": "Archived."}, status=403)

        files = request.FILES.getlist('attachments') or (
            [request.FILES.get('attachment')] if request.FILES.get('attachment') else []
        )

        if not files:
            return Response({"detail": "No files."}, status=400)

        created_msgs = []
        try:
            with transaction.atomic():
                for f in files:
                    mime, _ = mimetypes.guess_type(f.name)

                    # Salvar arquivo
                    m = self.get_serializer(data={'attachment': f, 'content': ''})
                    m.is_valid(raise_exception=True)
                    obj = m.save(
                        chat=chat,
                        role=ChatMessage.Role.USER,
                        attachment_type='image' if mime and mime.startswith('image/') else 'file',
                        original_filename=f.name
                    )
                    created_msgs.append(obj)

                    # Processamento RAG para documentos
                    processable_mimes = [
                        'application/pdf',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'text/plain'
                    ]
                    if obj.attachment_type == 'file' and mime in processable_mimes:
                        try:
                            logger.info(f"[RAG] Processando: {obj.original_filename}")
                            text = FileProcessor.extract_text(obj.attachment.path, mime)
                            if text:
                                chunks = FileProcessor.chunk_text(text)
                                if chunks:
                                    vector_service.add_document_chunks(
                                        user_id=chat.user.id,
                                        bot_id=chat.bot.id,
                                        chunks=chunks,
                                        source_name=obj.original_filename,
                                        message_id=obj.id
                                    )
                        except Exception as rag_error:
                            logger.error(f"[RAG ERROR] {obj.original_filename}: {rag_error}")

            if created_msgs:
                chat.last_message_at = created_msgs[-1].created_at
                chat.save()

            return Response(
                ChatMessageSerializer(created_msgs, many=True, context={'request': request}).data,
                status=201
            )
        except Exception as e:
            logger.error(f"Erro no upload: {e}")
            return Response({"detail": str(e)}, status=500)


# =============================================================================
# VIEWS DE ÁUDIO E TRANSCRIÇÃO
# =============================================================================

class AudioTranscriptionView(APIView):
    """Transcreve áudio usando Gemini."""
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def post(self, request, chat_pk):
        get_object_or_404(Chat, id=chat_pk, user=request.user)
        f = request.FILES.get('audio')
        if not f:
            return Response({"detail": "No audio."}, status=400)

        res = transcribe_audio_gemini(f)
        if res['success']:
            return Response({"transcription": res['transcription']}, status=200)
        return Response({"detail": res['error']}, status=500)


class VoiceInteractionView(APIView):
    """Interação por voz sem resposta em áudio."""
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def post(self, request, chat_pk):
        chat = get_object_or_404(Chat, id=chat_pk, user=request.user)
        f = request.FILES.get('audio')
        if not f:
            return Response({"detail": "No audio."}, status=400)

        try:
            res = handle_voice_interaction(chat.id, f, request.user)
            return Response({
                "transcription": res['transcription'],
                "ai_response_text": res['ai_response_text'],
                "user_message": ChatMessageSerializer(res['user_message'], context={'request': request}).data,
                "ai_messages": ChatMessageSerializer(res['ai_messages'], many=True, context={'request': request}).data
            }, status=200)
        except Exception as e:
            return Response({"detail": str(e)}, status=500)


class VoiceMessageView(APIView):
    """Processa mensagem de voz com resposta opcional em áudio."""
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def post(self, request, chat_pk):
        chat = get_object_or_404(Chat, id=chat_pk, user=request.user)
        f = request.FILES.get('audio') or request.FILES.get('file') or request.FILES.get('attachment')
        if not f:
            return Response({"detail": "No audio."}, status=400)

        reply_audio = str(request.data.get('reply_with_audio', 'false')).lower() == 'true'

        try:
            user_duration = int(float(request.data.get('duration', 0)))
        except (ValueError, TypeError):
            user_duration = 0

        try:
            res = handle_voice_message(chat.id, f, reply_audio, request.user)
            if user_duration > 0:
                res['user_message'].duration = user_duration
                res['user_message'].save()

            return Response([
                ChatMessageSerializer(res['user_message'], context={'request': request}).data,
                ChatMessageSerializer(res['ai_message'], context={'request': request}).data
            ], status=201)
        except Exception as e:
            return Response({"detail": str(e)}, status=500)


# =============================================================================
# VIEWS DE GERENCIAMENTO DE CHAT
# =============================================================================

class ArchiveChatView(APIView):
    """Arquiva chat atual e cria um novo."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, chat_id):
        c = get_object_or_404(Chat, id=chat_id, user=request.user)
        c.status = Chat.ChatStatus.ARCHIVED
        c.save()

        n = Chat.objects.create(
            user=request.user,
            bot=c.bot,
            status=Chat.ChatStatus.ACTIVE
        )
        return Response({"new_chat_id": n.id}, status=201)


class SetActiveChatView(APIView):
    """Define um chat arquivado como ativo."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, chat_id):
        c = get_object_or_404(Chat, id=chat_id, user=request.user)

        # Arquivar outros chats ativos do mesmo bot
        Chat.objects.filter(
            user=request.user,
            bot=c.bot,
            status=Chat.ChatStatus.ACTIVE
        ).update(status=Chat.ChatStatus.ARCHIVED)

        c.status = Chat.ChatStatus.ACTIVE
        c.last_message_at = timezone.now()
        c.save()

        return Response(
            ChatListSerializer(c, context={'request': request}).data,
            status=200
        )


class MessageLikeToggleView(APIView):
    """Toggle de like em uma mensagem."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, chat_pk, message_id):
        m = get_object_or_404(
            ChatMessage,
            id=message_id,
            chat_id=chat_pk,
            chat__user=request.user
        )
        m.liked = not m.liked
        m.save()
        return Response({'liked': m.liked}, status=200)


# =============================================================================
# VIEWS DE TTS
# =============================================================================

class CleanupFileResponse(FileResponse):
    """FileResponse que remove o arquivo após envio."""

    def __init__(self, *args, cleanup_path=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.cleanup_path = cleanup_path

    def close(self):
        super().close()
        if self.cleanup_path and os.path.exists(self.cleanup_path):
            try:
                os.remove(self.cleanup_path)
            except OSError:
                pass


class MessageTTSView(APIView):
    """Gera áudio TTS para uma mensagem específica."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, chat_pk, message_id):
        m = get_object_or_404(
            ChatMessage,
            id=message_id,
            chat_id=chat_pk,
            role=ChatMessage.Role.ASSISTANT
        )

        if not m.content:
            return Response({"detail": "No content"}, status=400)

        td = Path(settings.MEDIA_ROOT) / 'temp_tts'
        td.mkdir(parents=True, exist_ok=True)
        p = td / f"tts_{m.id}_{uuid.uuid4().hex[:8]}.wav"

        res = generate_tts_audio(m.content, str(p))
        if res['success']:
            return CleanupFileResponse(
                open(p, 'rb'),
                content_type='audio/wav',
                cleanup_path=str(p)
            )
        return Response({"detail": "Error"}, status=500)

# =============================================================================
# VIEWS DE CONTEXTO E FONTES (NOVO)
# =============================================================================

class ChatSourceViewSet(viewsets.ModelViewSet):
    """
    Manages KnowledgeSources attached to a Chat.
    Nested ViewSet: /chats/{chat_pk}/sources/
    """
    serializer_class = KnowledgeSourceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        chat_id = self.kwargs['chat_pk']
        chat = get_object_or_404(Chat, id=chat_id, user=self.request.user)
        return chat.sources.all().order_by('-created_at')

    def perform_create(self, serializer):
        # When creating a source inside a chat, we must link it to the chat
        chat_id = self.kwargs['chat_pk']
        chat = get_object_or_404(Chat, id=chat_id, user=self.request.user)
        
        # Save source (linked to user)
        instance = serializer.save(user=self.request.user)
        
        # Process Content Immediately
        extracted_text = ""
        try:
            if instance.source_type == KnowledgeSource.SourceType.FILE and instance.file:
                extracted_text = FileProcessor.extract_text(instance.file.path)
            elif instance.source_type in [KnowledgeSource.SourceType.URL, KnowledgeSource.SourceType.YOUTUBE] and instance.url:
                extracted_text = content_extractor.ContentExtractor.extract_from_url(instance.url)

            if extracted_text:
                instance.extracted_text = extracted_text
                instance.save(update_fields=['extracted_text'])
        except Exception as e:
            logger.error(f"Error extracting text for source {instance.id}: {e}")

        # Link to Chat
        chat.sources.add(instance)

    @action(detail=True, methods=['delete'])
    def remove(self, request, chat_pk=None, pk=None):
        # Helper to remove relationship without deleting the source entity itself (if shared)
        # But for now, user owns the source. We might want to just unlink.
        # However, standard DELETE destroys the object. 
        # Requirement: "Remove from chat". 
        # If the source is only used here, maybe delete? 
        # Safest: Unlink.
        chat = get_object_or_404(Chat, id=chat_pk, user=request.user)
        source = get_object_or_404(KnowledgeSource, id=pk, user=request.user)
        
        chat.sources.remove(source)
        return Response(status=status.HTTP_204_NO_CONTENT)


class ContextSourcesView(APIView):
    """
    Retorna a lista de fontes disponíveis para um chat (documentos indexados).
    LEGACY/HYBRID: Returns both vector docs (from messages) AND explicit chat sources.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, chat_id):
        chat = get_object_or_404(Chat, id=chat_id, user=request.user)
        
        sources = []
        
        # 1. Sources from Chat (Explicit)
        chat_sources = chat.sources.all()
        for s in chat_sources:
             sources.append({
                'id': f"ks_{s.id}", # Prefix to distinguish from legacy
                'name': s.title,
                'type': 'file' if s.source_type == 'FILE' else 'url',
                'selected': True # By default, chat sources are context
            })

        # 2. Legacy Sources (Vector Service)
        docs = vector_service.get_available_documents(request.user.id, chat.bot.id)
        for doc in docs:
            # We filter out duplicates if possible, but IDs differ.
            # Legacy docs usually come from ChatMessage attachments.
            # We keep them for backward compatibility.
            message_id = doc.get('message_id')
            source_id = str(message_id) if message_id else doc['source']
            
            sources.append({
                'id': source_id,
                'name': doc['source'],
                'type': 'kb' if doc.get('type') == 'knowledge_base' else 'file',
                'selected': False
            })
        
        return Response(sources, status=200)
