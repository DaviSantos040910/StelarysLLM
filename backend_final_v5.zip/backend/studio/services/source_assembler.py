import logging
from chat.models import ChatMessage
from chat.file_processor import FileProcessor
from chat.services.token_service import TokenService

logger = logging.getLogger(__name__)

class SourceAssemblyService:
    # Safety limit for context (Gemini 1.5 Pro is 1M+, Flash is 1M. We set a safe margin)
    MAX_CONTEXT_TOKENS = 800_000

    @staticmethod
    def get_context_from_config(chat_id: int, config: dict) -> str:
        """
        Reúne o conteúdo bruto dos arquivos selecionados e/ou histórico do chat.

        Args:
            chat_id: ID do chat.
            config: Dicionário contendo:
                - selectedSourceIds (list[int|str]): IDs das mensagens ou nomes de arquivos.
                - includeChatContext (bool): Se deve incluir o histórico de mensagens.

        Returns:
            str: O contexto montado pronto para o LLM.
        """
        context_parts = []
        current_tokens = 0

        # 1. Processar Arquivos Selecionados
        source_ids = config.get('selectedSourceIds', [])
        if source_ids:
            # Separar IDs numéricos (message_id) de strings (filenames/legacy)
            message_ids = []
            filenames = []
            
            for sid in source_ids:
                sid_str = str(sid)
                if sid_str.isdigit():
                    message_ids.append(int(sid_str))
                else:
                    filenames.append(sid_str)
            
            # Buscar mensagens pelos IDs
            messages_by_id = list(ChatMessage.objects.filter(id__in=message_ids, chat_id=chat_id))
            
            # Buscar mensagens pelos nomes de arquivo (fallback)
            messages_by_name = []
            if filenames:
                # Busca mensagens que tenham esses nomes de arquivo no chat
                # Atenção: Pode haver duplicatas, pegamos as mais recentes
                for fname in filenames:
                    msg = ChatMessage.objects.filter(chat_id=chat_id, original_filename=fname).order_by('-created_at').first()
                    # Evita duplicatas se já achou por ID (verifica ID se msg existe)
                    if msg:
                         already_found = any(m.id == msg.id for m in messages_by_id)
                         if not already_found:
                             messages_by_name.append(msg)
            
            all_messages = messages_by_id + messages_by_name

            for message in all_messages:
                # Check if we already hit the limit
                if current_tokens >= SourceAssemblyService.MAX_CONTEXT_TOKENS:
                    logger.warning(f"Context limit reached ({SourceAssemblyService.MAX_CONTEXT_TOKENS}). Skipping remaining files.")
                    context_parts.append("\n[SYSTEM: Maximum context size reached. Remaining files omitted.]")
                    break

                if message.attachment:
                    try:
                        file_path = message.attachment.path
                        file_name = message.original_filename or f"file_{message.id}"

                        # Cache Read-Through
                        content = message.extracted_text

                        if not content:
                            logger.info(f"Extracting text for message {message.id} (File: {file_name})")
                            # Extrai conteúdo usando o processador
                            content = FileProcessor.extract_text(file_path)

                            # Save to cache if successful
                            if content:
                                message.extracted_text = content
                                message.save(update_fields=['extracted_text'])
                        else:
                            logger.info(f"Using cached text for message {message.id}")

                        if content:
                            # Estimate tokens for this file
                            file_tokens = TokenService.estimate_tokens(content)

                            # Check if adding this file exceeds limit
                            if current_tokens + file_tokens > SourceAssemblyService.MAX_CONTEXT_TOKENS:
                                # Calculate how much space is left
                                space_left = SourceAssemblyService.MAX_CONTEXT_TOKENS - current_tokens
                                if space_left > 100: # Only include if reasonable chunk remains
                                    truncated_content = TokenService.truncate_to_token_limit(content, space_left)
                                    context_parts.append(f"\n--- FILE: {file_name} (Partial) ---\n{truncated_content}")
                                    current_tokens += space_left
                                else:
                                    logger.warning(f"Skipping file {file_name} due to full context.")
                            else:
                                context_parts.append(f"\n--- FILE: {file_name} ---\n{content}")
                                current_tokens += file_tokens
                        else:
                             logger.warning(f"Conteúdo vazio para arquivo {file_name} (ID: {message.id})")

                    except Exception as e:
                        logger.error(f"Erro ao processar arquivo da mensagem {message.id}: {e}")
                        context_parts.append(f"\n--- FILE: {message.original_filename} ---\n[Erro ao ler arquivo]")

        # 2. Processar Histórico do Chat (se solicitado)
        if config.get('includeChatContext'):
             # Recupera as últimas 50 mensagens para contexto
             chat_messages = ChatMessage.objects.filter(chat_id=chat_id).order_by('created_at')
             # Otimização: Pegamos as últimas X mensagens que cabem no token limit?
             # Por simplicidade, pegamos as últimas 50 e verificamos o token limit.
             
             history_buffer = []
             for msg in chat_messages:
                 role = "User" if msg.role == ChatMessage.Role.USER else "AI"
                 content = msg.content or ""
                 # Ignora mensagens com anexo grande que já foram processadas acima, foca no texto da conversa
                 if content:
                     history_buffer.append(f"{role}: {content}")
             
             full_history = "\n".join(history_buffer)
             
             # Verificar Tokens
             history_tokens = TokenService.estimate_tokens(full_history)
             if current_tokens + history_tokens > SourceAssemblyService.MAX_CONTEXT_TOKENS:
                  space_left = SourceAssemblyService.MAX_CONTEXT_TOKENS - current_tokens
                  if space_left > 100:
                      truncated_history = TokenService.truncate_to_token_limit(full_history, space_left)
                      context_parts.append(f"\n--- CHAT HISTORY (Partial) ---\n{truncated_history}")
             else:
                  context_parts.append(f"\n--- CHAT HISTORY ---\n{full_history}")

        return "\n".join(context_parts)
