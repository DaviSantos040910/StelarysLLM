# studio/schemas.py

# Using raw dictionaries for schemas to avoid dependency issues with google.genai.types
# and to ensure compatibility across different SDK versions/Python versions.

QUIZ_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "title": {"type": "STRING"},
        "questions": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "question": {"type": "STRING"},
                    "options": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    },
                    "correctAnswerIndex": {"type": "INTEGER"},
                    "explanation": {"type": "STRING"},
                    "hint": {"type": "STRING"}
                },
                "required": ["question", "options", "correctAnswerIndex", "explanation", "hint"]
            }
        }
    },
    "required": ["title", "questions"]
}

FLASHCARD_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "title": {"type": "STRING"},
        "cards": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "front": {"type": "STRING"},
                    "back": {"type": "STRING"}
                },
                "required": ["front", "back"]
            }
        }
    },
    "required": ["title", "cards"]
}

SUMMARY_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "title": {"type": "STRING"},
        "summary": {"type": "STRING"},
        "key_points": {
            "type": "ARRAY",
            "items": {"type": "STRING"}
        }
    },
    "required": ["title", "summary", "key_points"]
}

SLIDE_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "title": {"type": "STRING"},
        "slides": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "title": {"type": "STRING"},
                    "bullets": {
                        "type": "ARRAY",
                        "items": {"type": "STRING"}
                    }
                },
                "required": ["title", "bullets"]
            }
        }
    },
    "required": ["title", "slides"]
}
